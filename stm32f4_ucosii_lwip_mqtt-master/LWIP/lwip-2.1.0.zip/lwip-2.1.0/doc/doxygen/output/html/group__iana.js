var group__iana =
[
    [ "lwip_iana_hwtype", "group__iana.html#ga3d2bbfcb56c8adf3be8c8d12868cecfe", [
      [ "LWIP_IANA_HWTYPE_ETHERNET", "group__iana.html#gga3d2bbfcb56c8adf3be8c8d12868cecfea89e82e6ac55811bb26fe66ec029f2a0c", null ]
    ] ],
    [ "lwip_iana_port_number", "group__iana.html#gac9396d90585e49e9a287179bf5aa9ba0", [
      [ "LWIP_IANA_PORT_SMTP", "group__iana.html#ggac9396d90585e49e9a287179bf5aa9ba0ae2645895203ca3c54005afad053a813c", null ],
      [ "LWIP_IANA_PORT_DHCP_SERVER", "group__iana.html#ggac9396d90585e49e9a287179bf5aa9ba0ac70ae96c985cf3660e26aa496094916d", null ],
      [ "LWIP_IANA_PORT_DHCP_CLIENT", "group__iana.html#ggac9396d90585e49e9a287179bf5aa9ba0a9fcae1f16758e1ac35dab343fc897f40", null ],
      [ "LWIP_IANA_PORT_TFTP", "group__iana.html#ggac9396d90585e49e9a287179bf5aa9ba0a7b318226afef92e019b67227acf94050", null ],
      [ "LWIP_IANA_PORT_HTTP", "group__iana.html#ggac9396d90585e49e9a287179bf5aa9ba0a1c665cb8e57dff577f4966493c15b618", null ],
      [ "LWIP_IANA_PORT_SNTP", "group__iana.html#ggac9396d90585e49e9a287179bf5aa9ba0a79c377ce09e05cd4410a8865d41b3efb", null ],
      [ "LWIP_IANA_PORT_NETBIOS", "group__iana.html#ggac9396d90585e49e9a287179bf5aa9ba0ae1cf6eaab024b31aff5bf407d38e0ede", null ],
      [ "LWIP_IANA_PORT_SNMP", "group__iana.html#ggac9396d90585e49e9a287179bf5aa9ba0aeb10a37f0c48e053b138f65b843c45d3", null ],
      [ "LWIP_IANA_PORT_SNMP_TRAP", "group__iana.html#ggac9396d90585e49e9a287179bf5aa9ba0aff60c0d3e8eca210b7e4faca3491f4a8", null ],
      [ "LWIP_IANA_PORT_HTTPS", "group__iana.html#ggac9396d90585e49e9a287179bf5aa9ba0ad07fb8ff2b18006405d904b5b3810c88", null ],
      [ "LWIP_IANA_PORT_SMTPS", "group__iana.html#ggac9396d90585e49e9a287179bf5aa9ba0a88f8872246977c6e24c617266ada1a3b", null ],
      [ "LWIP_IANA_PORT_MQTT", "group__iana.html#ggac9396d90585e49e9a287179bf5aa9ba0a172d486d82c552ef3540cf8d61b14b22", null ],
      [ "LWIP_IANA_PORT_MDNS", "group__iana.html#ggac9396d90585e49e9a287179bf5aa9ba0a839da325f45916d7b27d53d5e5e97dc6", null ],
      [ "LWIP_IANA_PORT_SECURE_MQTT", "group__iana.html#ggac9396d90585e49e9a287179bf5aa9ba0ab833e9dc7646bd7affde45691bc66601", null ]
    ] ]
];