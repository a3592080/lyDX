var group__lwip__opts__mem =
[
    [ "LWIP_ALLOW_MEM_FREE_FROM_OTHER_CONTEXT", "group__lwip__opts__mem.html#ga0a3ef6098813c103e5aba07da76e15e2", null ],
    [ "MEM_ALIGNMENT", "group__lwip__opts__mem.html#ga97343214666ee6dcb18c0bd77b441ea7", null ],
    [ "MEM_LIBC_MALLOC", "group__lwip__opts__mem.html#ga4ef345cc270912bd2230b1c5ec51dfc8", null ],
    [ "MEM_OVERFLOW_CHECK", "group__lwip__opts__mem.html#gae331a198bd06100b90ea020cd5f07f4e", null ],
    [ "MEM_SANITY_CHECK", "group__lwip__opts__mem.html#ga90b17afabb93986a162c327ed30bb4d3", null ],
    [ "MEM_SIZE", "group__lwip__opts__mem.html#ga2dcf8c45f945dd0c4301a94700f2112c", null ],
    [ "MEM_USE_POOLS", "group__lwip__opts__mem.html#gaddca3141bc7037241769eb152b6f89ba", null ],
    [ "MEM_USE_POOLS_TRY_BIGGER_POOL", "group__lwip__opts__mem.html#gaba8be68e8fd0716b723ce4569ed89f82", null ],
    [ "MEMP_MEM_INIT", "group__lwip__opts__mem.html#gaa2f25586972d1cbc1ff0dcdc6f15a1b0", null ],
    [ "MEMP_MEM_MALLOC", "group__lwip__opts__mem.html#gae93af697d27bbcefa6a28052d90f2f38", null ],
    [ "MEMP_OVERFLOW_CHECK", "group__lwip__opts__mem.html#ga27fdd01194a42fc41a7716b72cdb49e3", null ],
    [ "MEMP_SANITY_CHECK", "group__lwip__opts__mem.html#ga0838947193e222a9f46b582e01e5beff", null ],
    [ "MEMP_USE_CUSTOM_POOLS", "group__lwip__opts__mem.html#ga69de593b8ffd4f1c249f03e48e11983b", null ]
];