var group__netifs =
[
    [ "IEEE 802.1D bridge", "group__bridgeif.html", "group__bridgeif" ],
    [ "6LoWPAN (RFC4944)", "group__sixlowpan.html", "group__sixlowpan" ],
    [ "6LoWPAN over BLE (RFC7668)", "group__rfc7668if.html", "group__rfc7668if" ],
    [ "PPP", "group__ppp.html", null ],
    [ "SLIP", "group__slipif.html", "group__slipif" ],
    [ "ZEP - ZigBee Encapsulation Protocol", "group__zepif.html", "group__zepif" ]
];