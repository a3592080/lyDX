var group__netconn__tcp =
[
    [ "netconn_listen", "group__netconn__tcp.html#ga43e3f4c2169dec0f666c502e490416b7", null ],
    [ "netconn_write", "group__netconn__tcp.html#gafea5e9b90770a7c6cd0762ceb65e5b46", null ],
    [ "netconn_accept", "group__netconn__tcp.html#ga13593148f60f7bbc6a505b567f175d69", null ],
    [ "netconn_close", "group__netconn__tcp.html#ga25bb1c1c9928f91f53149a026e2e2624", null ],
    [ "netconn_listen_with_backlog", "group__netconn__tcp.html#ga84333ba8e7cdf45558d2b4795f53265d", null ],
    [ "netconn_recv_tcp_pbuf", "group__netconn__tcp.html#ga6893cb7648733d1f05696bac94e10490", null ],
    [ "netconn_recv_tcp_pbuf_flags", "group__netconn__tcp.html#gabb8a242c445ef928c23258a2b2344294", null ],
    [ "netconn_shutdown", "group__netconn__tcp.html#ga6ec6b2cf7b0f59e9371e38ae7dea2a63", null ],
    [ "netconn_write_partly", "group__netconn__tcp.html#gacf9ce6f71652739d6be2ca83f7c423bf", null ]
];