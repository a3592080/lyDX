var group__lwip__opts__socket =
[
    [ "LWIP_COMPAT_SOCKETS", "group__lwip__opts__socket.html#gafed2811f031822ec5afa1ee211fb7447", null ],
    [ "LWIP_FIONREAD_LINUXMODE", "group__lwip__opts__socket.html#ga0543eea2abe390d0bdc843c33debd762", null ],
    [ "LWIP_POSIX_SOCKETS_IO_NAMES", "group__lwip__opts__socket.html#ga484c38ab08f60d5b3335d23d31f9a402", null ],
    [ "LWIP_SO_LINGER", "group__lwip__opts__socket.html#gaa91292d5d014dc1c6f1c1f4166269a1d", null ],
    [ "LWIP_SO_RCVBUF", "group__lwip__opts__socket.html#ga06390cebcf4d13d3d47a11365e5fcd28", null ],
    [ "LWIP_SO_RCVTIMEO", "group__lwip__opts__socket.html#ga91af3ade95b20b9a60c65ed0380fa0ed", null ],
    [ "LWIP_SO_SNDRCVTIMEO_NONSTANDARD", "group__lwip__opts__socket.html#ga5b115bacb569763d8a3889a12229e942", null ],
    [ "LWIP_SO_SNDTIMEO", "group__lwip__opts__socket.html#ga1162cb685f202d9b21c11344b8209a58", null ],
    [ "LWIP_SOCKET", "group__lwip__opts__socket.html#ga1cb62ce61ac39d7d6728ae5d3d3b927f", null ],
    [ "LWIP_SOCKET_OFFSET", "group__lwip__opts__socket.html#gad0197c845fbb44c920b272f0fef3b57e", null ],
    [ "LWIP_SOCKET_POLL", "group__lwip__opts__socket.html#ga6c14d705e3321429683f24de9f5a7200", null ],
    [ "LWIP_SOCKET_SELECT", "group__lwip__opts__socket.html#ga68417078b71b0be9735256f52933dcdb", null ],
    [ "LWIP_TCP_CLOSE_TIMEOUT_MS_DEFAULT", "group__lwip__opts__socket.html#ga3e7498d5d2921f0df3792de72f384d36", null ],
    [ "LWIP_TCP_KEEPALIVE", "group__lwip__opts__socket.html#ga8b9369ab260f032686a81c77c5b4db77", null ],
    [ "RECV_BUFSIZE_DEFAULT", "group__lwip__opts__socket.html#ga5dbd0a61f30ae6c6bfbda635095f138d", null ],
    [ "SO_REUSE", "group__lwip__opts__socket.html#gaf3822feed320cf8439b083ee525e4942", null ],
    [ "SO_REUSE_RXTOALL", "group__lwip__opts__socket.html#gae9395d83af89002343e5782130f52f44", null ]
];