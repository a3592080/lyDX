var group__netif__ip6 =
[
    [ "netif_ip6_addr", "group__netif__ip6.html#ga7ec0623f1a858a0cdb187beaa89df365", null ],
    [ "netif_ip_addr6", "group__netif__ip6.html#gae424e336fe9f013b30d4065fd35c91ee", null ],
    [ "netif_add_ip6_address", "group__netif__ip6.html#gab0727fba5f5b3fed8d7013775506f327", null ],
    [ "netif_create_ip6_linklocal_address", "group__netif__ip6.html#gae864211a5eb052deb5da7bc7e3427fb9", null ],
    [ "netif_ip6_addr_set", "group__netif__ip6.html#gae21572fdbd8664d22a1b281a6c31c9bb", null ],
    [ "netif_ip6_addr_set_state", "group__netif__ip6.html#ga9cde7286535c7f037a9b16052561b91f", null ]
];