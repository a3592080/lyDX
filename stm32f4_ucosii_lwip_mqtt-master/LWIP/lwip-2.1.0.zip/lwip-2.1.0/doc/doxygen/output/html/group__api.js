var group__api =
[
    [ "\"raw\" APIs", "group__callbackstyle__api.html", "group__callbackstyle__api" ],
    [ "Sequential-style APIs", "group__sequential__api.html", "group__sequential__api" ],
    [ "Socket API", "group__socket.html", "group__socket" ]
];